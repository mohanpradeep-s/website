import React from 'react'

const AllProducts = () => {
  return (
    <div>AllProducts</div>
  )
}

export default AllProducts