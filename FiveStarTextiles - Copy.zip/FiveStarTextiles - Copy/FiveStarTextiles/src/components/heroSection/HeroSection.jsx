import React from 'react'

const HeroSection = () => {
  return (
    <div>
        <img src="https://img.freepik.com/free-photo/vibrant-fashion-textile-pattern-collection-display-generative-ai_188544-9090.jpg" alt="" className='w-screen'/>
    </div>
  )
}

export default HeroSection