// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyBWD00MXa2MoxcL82yYFxvnnRhRdeLGLAo",
  authDomain: "fivestartextiles-7a1e5.firebaseapp.com",
  projectId: "fivestartextiles-7a1e5",
  storageBucket: "fivestartextiles-7a1e5.appspot.com",
  messagingSenderId: "639185924713",
  appId: "1:639185924713:web:58a6718df901826c6828f8",
  measurementId: "G-69FCVLR637"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const fireDB = getFirestore(app);
const auth = getAuth(app)
export {fireDB,auth } ;